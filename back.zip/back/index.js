const express = require('express');
const app = express();
const cors = require('cors');

const PORT = 3000;
const hostname = 'localhost'

//-------------------------------------------------------------------------

const controllerCliente = require('./controller/controllerCliente');
const controllerEntrega = require('./controller/controllerEntrega');
const controllerEstoque = require('./controller/controllerEstoque');
const controllerFabricante = require('./controller/controllerFabricante');
const controllerItemPedido = require('./controller/controllerItemPedido');
const controllerPagamento = require('./controller/controllerPagamento');
const controllerPedido = require('./controller/controllerPedido');
const controllerProduto = require('./controller/controllerProduto');
const controllerReabastecimento = require('./controller/controllerReabastecimento');

//-------------------------------------------------------------------------

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors());

//-------------------------------------------------------------------------

// Clientes
app.post('/cliente', controllerCliente.cadastrarCliente);
app.get('/cliente', controllerCliente.listarCliente);
app.delete('/cliente/:id', controllerCliente.excluirCliente);
app.put('/cliente/:id', controllerCliente.atualizarCliente); 

// Entregas
app.post('/entrega', controllerEntrega.cadastrarEntrega);
app.get('/entrega', controllerEntrega.listarEntrega);
app.delete('/entrega/:id', controllerEntrega.excluirEntrega);

// Estoque
app.post('/estoque', controllerEstoque.cadastrarEstoque);
app.get('/estoque', controllerEstoque.listarEstoque);
app.delete('/estoque/:id', controllerEstoque.excluirEstoque);

// Fabricantes
app.post('/fabricante', controllerFabricante.cadastrarFabricante);
app.get('/fabricante', controllerFabricante.listarFabricante);
app.delete('/fabricante/:id', controllerFabricante.excluirFabricante);

// Itens de Pedido
app.post('/itemPedido', controllerItemPedido.cadastrarItemPedido);
app.get('/itemPedido', controllerItemPedido.listarItemPedido);
app.delete('/itemPedido/:id', controllerItemPedido.excluirItemPedido); 

// Pagamentos
app.post('/pagamento', controllerPagamento.cadastrarPagamento);
app.get('/pagamento', controllerPagamento.listarPagamento);
app.delete('/pagamento/:id', controllerPagamento.excluirPagamento);

// Pedidos
app.post('/pedido', controllerPedido.cadastrarPedido);
app.get('/pedido', controllerPedido.listarPedido);
app.delete('/pedido/:id', controllerPedido.excluirPedido);

// Produtos
app.post('/produto', controllerProduto.cadastrarProduto);
app.get('/produto', controllerProduto.listarProduto);
app.delete('/produto/:id', controllerProduto.excluirProduto);

// Reabastecimentos
app.post('/reabastecimento', controllerReabastecimento.cadastrarReabastecimento);
app.get('/reabastecimento', controllerReabastecimento.listarReabastecimento);
app.delete('/reabastecimento/:id', controllerReabastecimento.excluirReabastecimento);

//-------------------------------------------------------------------------
app.get('/', (req, res) => {
    res.status(200).json({ message: 'Ativo' });
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
