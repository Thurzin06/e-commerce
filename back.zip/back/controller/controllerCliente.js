const { Cliente } = require('../model/associacao')

const cadastrarCliente = async (req, res) => {
    const valores = req.body
    console.log(valores)
    try {
        const pesq = Cliente.create(valores, { raw: true })
        res.status(201).json({ message: "Cadastro Concluído com Sucesso" })
    } catch (err) {
        console.error('Erro ao cadastrar o usuário', err)
        res.status(500).json({ message: 'Erro ao cadastrar o usuário' })
    }
}

/*------------------------------------------------*/

const listarCliente = async (req, res) => {
    try {
        const pesq = await Cliente.findAll()
        res.status(200).json(pesq)
    } catch (err) {
        res.status(500).json({ message: 'Erro na listagem dos Clientes' })
    }
}

const excluirCliente = async (req,res) =>{
    try{
        const cpfCliente = req.params.id        
        await Cliente.destroy({where: {cpfCliente}})
        res.status(200).json({message: 'cliente exluido com sucesso'})
    }catch(err){
        res.status(500).json({message: 'Erro ao excluir cliente'})
    }
}

const atualizarCliente = async (req,res) =>{
    const valores = req.body
    try{
        await Cliente.update(valores, {where: {cpfCliente: valores.cpfCliente}})
        res.status(200).json({message: 'sucesso ao atualizar cliente'})
    }catch(err){
        console.error(err)
        res.status(500).json({message: 'Erro ao atualizar cliente'})
    }
}

module.exports = { cadastrarCliente, listarCliente, excluirCliente, atualizarCliente }