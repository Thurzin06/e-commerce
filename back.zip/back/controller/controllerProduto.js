const { Produto } = require('../model/associacao')

const cadastrarProduto = async (req, res) => {
    const valores = req.body
    console.log(valores)
    try {
        const pesq = Produto.create(valores, { raw: true })
        res.status(201).json({ message: "Cadastro Concluído com Sucesso" })
    } catch (err) {
        console.error('Erro ao cadastrar o usuário', err)
        res.status(500).json({ message: 'Erro ao cadastrar o produto' })
    }
}

/*------------------------------------------------*/

const listarProduto = async (req, res) => {
    try {
        const pesq = await Produto.findAll()
        res.status(200).json(pesq)
    } catch (err) {
        res.status(500).json({ message: 'Erro na listagem dos Produtos' })
    }
}

const excluirProduto = async (req,res) =>{
    try{
        const nomeProduto = req.params.id 
        await Produto.destroy({where: {nomeProduto}})
        res.status(200).json({message: 'cliente exluido com sucesso'})
    }catch(err){
        res.status(500).json({message: 'Erro ao excluir cliente'})
    }
}


module.exports = { cadastrarProduto, listarProduto, excluirProduto }