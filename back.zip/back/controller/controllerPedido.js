const { Pedido } = require('../model/associacao')

const cadastrarPedido = async (req, res) => {
    const valores = req.body
    console.log(valores)
    try {
        const pesq = await Pedido.create(valores, { raw: true })
        res.status(201).json({ message: "Cadastro Concluído com Sucesso" })
    } catch (err) {
        console.error('Erro ao cadastrar o usuário', err)
        res.status(500).json({ message: 'Erro ao cadastrar os pedidos' })
    }
}

/*------------------------------------------------*/

const listarPedido = async (req, res) => {
    try {
        const pesq = await Pedido.findAll()
        res.status(200).json(pesq)
    } catch (err) {
        res.status(500).json({ message: 'Erro na listagem dos Pedidos' })
    }
}

const excluirPedido = async (req,res) =>{
    try{
        const codPedido = req.params.id 
        await Pedido.destroy({where: {codPedido}})
        res.status(200).json({message: 'Pedido exluido com sucesso'})
    }catch(err){
        res.status(500).json({message: 'Erro ao excluir pedido'})
    }
}


module.exports = { cadastrarPedido, listarPedido, excluirPedido }