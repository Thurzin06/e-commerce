const { Entrega } = require('../model/associacao')

const cadastrarEntrega = async (req, res) => {
    const valores = req.body
    console.log(valores)
    try {
        const pesq = Entrega.create(valores, { raw: true })
        res.status(201).json({ message: "Cadastro Concluído com Sucesso" })
    } catch (err) {
        console.error('Erro ao cadastrar a entrega', err)
        res.status(500).json({ message: 'Erro ao cadastrar a entrega' })
    }
}

/*------------------------------------------------*/

const listarEntrega = async (req, res) => {
    try {
        const pesq = await Entrega.findAll()
        res.status(200).json(pesq)
    } catch (err) {
        res.status(500).json({ message: 'Erro na listagem das entregas' })
    }
}

const excluirEntrega = async (req,res) =>{
    try{
        const codEntrega = req.params.id 
        await Entrega.destroy({where: {codEntrega}})
        res.status(200).json({message: 'entrega exluida com sucesso'})
    }catch(err){
        res.status(500).json({message: 'Erro ao excluir entrega'})
    }
}

module.exports = { cadastrarEntrega, listarEntrega, excluirEntrega }