const { Estoque } = require('../model/associacao')

const cadastrarEstoque = async (req, res) => {
    const valores = req.body
    console.log(valores)
    try {
        const pesq = Estoque.create(valores, { raw: true })
        res.status(201).json({ message: "Cadastro Concluído com Sucesso" })
    } catch (err) {
        console.error('Erro ao cadastrar estoque', err)
        res.status(500).json({ message: 'Erro ao cadastrar o estoque' })
    }
}

/*------------------------------------------------*/

const listarEstoque = async (req, res) => {
    try {
        const pesq = await Estoque.findAll()
        res.status(200).json(pesq)
    } catch (err) {
        res.status(500).json({ message: 'Erro na listagem do estoque' })
    }
}

const excluirEstoque = async (req,res) =>{
    try{
        const codEstoque = req.params.id 
        await Estoque.destroy({where: {codEstoque}})
        res.status(200).json({message: 'estoque exluido com sucesso'})
    }catch(err){
        res.status(500).json({message: 'Erro ao excluir estoque'})
    }
}

module.exports = { cadastrarEstoque, listarEstoque, excluirEstoque }